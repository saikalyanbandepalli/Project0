package com.example.docker.dockerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

import React from 'react';
const Maincontext = React.createContext();
export {Maincontext};